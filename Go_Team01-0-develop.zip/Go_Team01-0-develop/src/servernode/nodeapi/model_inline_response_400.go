/*
 * Team01 Server
 *
 * API version: 1.0.0
 */
package teamnode01

type InlineResponse400 struct {

	Error_ string `json:"error,omitempty"`
}
