/*
 * Team01 Server
 *
 * API version: 1.0.0
 */
package teamnode01

type InlineResponse201 struct {

	Thanks string `json:"thanks,omitempty"`

	Change int32 `json:"change,omitempty"`
}
