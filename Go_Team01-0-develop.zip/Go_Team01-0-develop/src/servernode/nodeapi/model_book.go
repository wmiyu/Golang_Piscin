/*
 * Team01 Server
 *
 * API version: 1.0.0
 */
package teamnode01

type Book struct {
	Uuid 	string	`json:"uuid"`
	Name 	string	`json:"name"`	
}
