package gococoa

// #cgo CFLAGS: -x objective-c
// #cgo LDFLAGS: -framework Cocoa
