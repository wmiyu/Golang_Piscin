#import <Cocoa/Cocoa.h>

void InitApplication();
void RunApplication();